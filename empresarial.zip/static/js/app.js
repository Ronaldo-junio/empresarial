document.addEventListener('DOMContentLoaded', function () {

  // Auto-hide flash messages after 4 seconds
  document.querySelectorAll('.flash-msg').forEach(function (el) {
    setTimeout(function () {
      var bsAlert = bootstrap.Alert.getOrCreateInstance(el);
      bsAlert.close();
    }, 4000);
  });

  // Sidebar toggle (mobile)
  var sidebarToggle = document.getElementById('sidebarToggle');
  var sidebar = document.getElementById('sidebar');
  var overlay = document.getElementById('overlay');

  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener('click', function () {
      sidebar.classList.toggle('open');
      if (overlay) overlay.classList.toggle('d-none');
    });
  }

  if (overlay && sidebar) {
    overlay.addEventListener('click', function () {
      sidebar.classList.remove('open');
      overlay.classList.add('d-none');
    });
  }

  // Mark rejection textarea invalid before submit
  var motivoField = document.getElementById('motivo-rejeicao');
  if (motivoField) {
    motivoField.addEventListener('input', function () {
      if (this.value.trim()) {
        this.classList.remove('is-invalid');
      }
    });
  }

  // Highlight active nav on click
  document.querySelectorAll('.sidebar-link').forEach(function (link) {
    link.addEventListener('click', function () {
      document.querySelectorAll('.sidebar-link').forEach(function (l) {
        l.classList.remove('active');
      });
      link.classList.add('active');
    });
  });

});
